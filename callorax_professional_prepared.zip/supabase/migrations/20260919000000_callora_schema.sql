-- ====================================================================
-- CallOra Smart Dialer & Caller ID - Production Supabase Migration
-- Safe & Idempotent Schema Migration (Preserves Existing Tables)
-- RLS Enabled on All Tables
-- ====================================================================

-- 1. PROFILES (Safely enhance existing profiles table)
ALTER TABLE IF EXISTS public.profiles 
  ADD COLUMN IF NOT EXISTS full_name TEXT,
  ADD COLUMN IF NOT EXISTS phone_number TEXT,
  ADD COLUMN IF NOT EXISTS avatar_url TEXT,
  ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'user',
  ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS is_pro BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS subscription_tier TEXT DEFAULT 'free',
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Public profiles are viewable by everyone') THEN
    CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can insert their own profile') THEN
    CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'profiles' AND policyname = 'Users can update own profile') THEN
    CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
  END IF;
END $$;

-- 2. PAYMENT REQUESTS (Safely enhance existing payment_requests table)
CREATE TABLE IF NOT EXISTS public.payment_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_tier TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  transaction_id TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  reviewed_at TIMESTAMPTZ
);

ALTER TABLE public.payment_requests
  ADD COLUMN IF NOT EXISTS amount_pkr NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS amount_usdt NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sender_account_title TEXT,
  ADD COLUMN IF NOT EXISTS receipt_storage_path TEXT,
  ADD COLUMN IF NOT EXISTS admin_notes TEXT,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.payment_requests ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'payment_requests' AND policyname = 'Users can view own payment requests') THEN
    CREATE POLICY "Users can view own payment requests" ON public.payment_requests FOR SELECT USING (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'payment_requests' AND policyname = 'Users can insert payment requests') THEN
    CREATE POLICY "Users can insert payment requests" ON public.payment_requests FOR INSERT WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'payment_requests' AND policyname = 'Admins can view all payment requests') THEN
    CREATE POLICY "Admins can view all payment requests" ON public.payment_requests FOR ALL USING (
      EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = auth.uid() AND profiles.role IN ('admin', 'superadmin'))
    );
  END IF;
END $$;

-- 3. COMMUNITY POSTS & COMMENTS (Safely enhance existing posts/comments)
CREATE TABLE IF NOT EXISTS public.posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name TEXT,
  content TEXT NOT NULL,
  image_url TEXT,
  likes_count INT DEFAULT 0,
  comments_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.posts
  ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'scam_alert',
  ADD COLUMN IF NOT EXISTS flagged_number TEXT,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'posts' AND policyname = 'Posts are viewable by all authenticated users') THEN
    CREATE POLICY "Posts are viewable by all authenticated users" ON public.posts FOR SELECT USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'posts' AND policyname = 'Authenticated users can create posts') THEN
    CREATE POLICY "Authenticated users can create posts" ON public.posts FOR INSERT WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'posts' AND policyname = 'Authors and admins can delete posts') THEN
    CREATE POLICY "Authors and admins can delete posts" ON public.posts FOR DELETE USING (
      auth.uid() = user_id OR EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = auth.uid() AND profiles.role IN ('admin', 'superadmin'))
    );
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name TEXT,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'comments' AND policyname = 'Comments viewable by all') THEN
    CREATE POLICY "Comments viewable by all" ON public.comments FOR SELECT USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'comments' AND policyname = 'Users can insert comments') THEN
    CREATE POLICY "Users can insert comments" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

-- 4. CALLER DIRECTORY (Caller ID, Spam Radar & Verified Businesses)
CREATE TABLE IF NOT EXISTS public.caller_directory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  organization TEXT,
  risk_level TEXT DEFAULT 'safe', -- 'safe', 'warning', 'severe'
  spam_reports_count INT DEFAULT 0,
  is_verified_business BOOLEAN DEFAULT FALSE,
  category TEXT DEFAULT 'General',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.caller_directory ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'caller_directory' AND policyname = 'Caller directory viewable by everyone') THEN
    CREATE POLICY "Caller directory viewable by everyone" ON public.caller_directory FOR SELECT USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'caller_directory' AND policyname = 'Admins can manage caller directory') THEN
    CREATE POLICY "Admins can manage caller directory" ON public.caller_directory FOR ALL USING (
      EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = auth.uid() AND profiles.role IN ('admin', 'superadmin'))
    );
  END IF;
END $$;

-- 5. SPAM REPORTS (Community Telemetry & Fraud Reporting)
CREATE TABLE IF NOT EXISTS public.spam_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  phone_number TEXT NOT NULL,
  caller_name TEXT,
  risk_level TEXT DEFAULT 'warning',
  details TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.spam_reports ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'spam_reports' AND policyname = 'Users can insert spam reports') THEN
    CREATE POLICY "Users can insert spam reports" ON public.spam_reports FOR INSERT WITH CHECK (auth.uid() = reporter_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'spam_reports' AND policyname = 'Admins can view all spam reports') THEN
    CREATE POLICY "Admins can view all spam reports" ON public.spam_reports FOR SELECT USING (
      EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = auth.uid() AND profiles.role IN ('admin', 'superadmin'))
    );
  END IF;
END $$;

-- 6. SUBSCRIPTIONS (Tier Management)
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_tier TEXT NOT NULL,
  status TEXT DEFAULT 'active', -- 'active', 'expired', 'cancelled'
  starts_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'subscriptions' AND policyname = 'Users can view own subscriptions') THEN
    CREATE POLICY "Users can view own subscriptions" ON public.subscriptions FOR SELECT USING (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'subscriptions' AND policyname = 'Admins can manage subscriptions') THEN
    CREATE POLICY "Admins can manage subscriptions" ON public.subscriptions FOR ALL USING (
      EXISTS (SELECT 1 FROM public.profiles WHERE profiles.id = auth.uid() AND profiles.role IN ('admin', 'superadmin'))
    );
  END IF;
END $$;

-- 7. APP SETTINGS (Remote Config for Payment Details & System Notices)
CREATE TABLE IF NOT EXISTS public.app_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'app_settings' AND policyname = 'App settings viewable by everyone') THEN
    CREATE POLICY "App settings viewable by everyone" ON public.app_settings FOR SELECT USING (true);
  END IF;
END $$;

-- Seed default app settings
INSERT INTO public.app_settings (key, value)
VALUES 
  ('easypaisa_account', '{"number": "PK97TMFB0000000022443615", "title": "CallOra Payments"}'::jsonb),
  ('binance_trc20', '{"address": "TG1hEHkNkMPn1VmLvzY3nXcjAUwgn2cvjL"}'::jsonb),
  ('binance_bep20', '{"address": "0xa289058b6b204953a9cf2d4154325e604ca80105"}'::jsonb)
ON CONFLICT (key) DO NOTHING;


-- 8. CALLORAX PLAN CATALOG (idempotent)
CREATE TABLE IF NOT EXISTS public.plan_catalog (
  id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  price_pkr NUMERIC NOT NULL DEFAULT 0,
  duration_days INT,
  tier TEXT NOT NULL,
  no_ads BOOLEAN NOT NULL DEFAULT FALSE,
  verified_badge TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.plan_catalog ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='plan_catalog' AND policyname='Plan catalog is public') THEN
    CREATE POLICY "Plan catalog is public" ON public.plan_catalog FOR SELECT USING (active = true);
  END IF;
END $$;

INSERT INTO public.plan_catalog (id,display_name,price_pkr,duration_days,tier,no_ads,verified_badge)
VALUES
 ('trial_3d','3 Days Pro Free Trial',0,3,'pro',true,'green'),
 ('pro_1m','1 Month Pro',99,30,'pro',true,'green'),
 ('pro_3m','3 Months Pro',199,90,'pro',true,'green'),
 ('pro_6m','6 Months Pro',499,180,'pro',true,'green'),
 ('premium_1y','1 Year Premium',3999,365,'premium',true,'gray'),
 ('lifetime','Lifetime Access Pro+Premium',4999,NULL,'lifetime',true,'green')
ON CONFLICT (id) DO UPDATE SET
 display_name=EXCLUDED.display_name, price_pkr=EXCLUDED.price_pkr,
 duration_days=EXCLUDED.duration_days, tier=EXCLUDED.tier,
 no_ads=EXCLUDED.no_ads, verified_badge=EXCLUDED.verified_badge;

-- 9. THEME / STORE CATALOG
CREATE TABLE IF NOT EXISTS public.themes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  preview_url TEXT,
  colors JSONB NOT NULL DEFAULT '{}'::jsonb,
  typography JSONB NOT NULL DEFAULT '{}'::jsonb,
  dialer_style JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_premium BOOLEAN NOT NULL DEFAULT FALSE,
  is_pro BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.themes ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='themes' AND policyname='Active themes are public') THEN
    CREATE POLICY "Active themes are public" ON public.themes FOR SELECT USING (is_active=true);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS public.user_themes (
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  theme_id UUID REFERENCES public.themes(id) ON DELETE CASCADE,
  downloaded_at TIMESTAMPTZ DEFAULT NOW(),
  is_favorite BOOLEAN DEFAULT FALSE,
  PRIMARY KEY (user_id, theme_id)
);
ALTER TABLE public.user_themes ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='user_themes' AND policyname='Users manage own themes') THEN
    CREATE POLICY "Users manage own themes" ON public.user_themes FOR ALL USING (auth.uid()=user_id) WITH CHECK (auth.uid()=user_id);
  END IF;
END $$;

-- Seed the built-in visual theme catalog.
INSERT INTO public.themes (slug,name,colors,is_premium,is_pro) VALUES
 ('dark','Dark','{"background":"#000000","primary":"#8B5CF6"}',false,false),
 ('light','Light','{"background":"#F8FAFC","primary":"#7C3AED"}',false,false),
 ('midnight','Midnight','{"background":"#030712","primary":"#38BDF8"}',false,false),
 ('purple','Purple','{"background":"#13071E","primary":"#A855F7"}',false,false),
 ('blue','Blue','{"background":"#0B132B","primary":"#2563EB"}',false,false),
 ('cyan','Cyan','{"background":"#04181B","primary":"#06B6D4"}',false,false),
 ('violet','Violet','{"background":"#0E0720","primary":"#7C3AED"}',false,false),
 ('emerald','Emerald','{"background":"#02170E","primary":"#10B981"}',false,false),
 ('rose','Rose','{"background":"#1A060B","primary":"#F43F5E"}',false,false),
 ('sunset','Sunset','{"background":"#180A04","primary":"#F97316"}',false,false),
 ('mixed-premium','Mixed Premium','{"background":"#0C0A14","primary":"#EAB308","secondary":"#A855F7"}',true,false)
ON CONFLICT (slug) DO NOTHING;

-- 10. USER SETTINGS / STORE DOWNLOAD PREFERENCES
CREATE TABLE IF NOT EXISTS public.user_settings (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  selected_theme TEXT DEFAULT 'dark',
  auto_download_store_assets BOOLEAN DEFAULT FALSE,
  storage_limit_mb INT DEFAULT 1024,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename='user_settings' AND policyname='Users manage own settings') THEN
    CREATE POLICY "Users manage own settings" ON public.user_settings FOR ALL USING (auth.uid()=user_id) WITH CHECK (auth.uid()=user_id);
  END IF;
END $$;
