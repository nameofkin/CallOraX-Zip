package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppTheme(val displayName: String, val isPremiumOnly: Boolean = false) {
    DARK("Dark", false),
    LIGHT("Light", false),
    MIDNIGHT("Midnight", false),
    PURPLE("Purple", false),
    BLUE("Blue", false),
    CYAN("Cyan", false),
    VIOLET("Violet", true),
    EMERALD("Emerald", true),
    ROSE("Rose", true),
    SUNSET("Sunset", true),
    MIXED_PREMIUM("Mixed Premium", true)
}

private val DarkScheme = darkColorScheme(
    primary = DarkPrimary,
    secondary = DarkSecondary,
    tertiary = DarkTertiary,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = CardSurfaceDark,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = BorderDark
)

private val LightScheme = lightColorScheme(
    primary = LightPrimary,
    secondary = LightSecondary,
    tertiary = LightTertiary,
    background = LightBackground,
    surface = LightSurface,
    surfaceVariant = LightSurfaceVariant,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    outline = Color(0xFFE2E8F0)
)

private val MidnightScheme = darkColorScheme(
    primary = MidnightPrimary,
    secondary = MidnightSecondary,
    tertiary = MidnightTertiary,
    background = MidnightBackground,
    surface = MidnightSurface,
    surfaceVariant = Color(0xFF1E293B),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF334155)
)

private val PurpleScheme = darkColorScheme(
    primary = PurpleThemePrimary,
    secondary = PurpleThemeSecondary,
    tertiary = PurpleThemeTertiary,
    background = PurpleThemeBackground,
    surface = PurpleThemeSurface,
    surfaceVariant = Color(0xFF2E1065),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF581C87)
)

private val BlueScheme = darkColorScheme(
    primary = BlueThemePrimary,
    secondary = BlueThemeSecondary,
    tertiary = BlueThemeTertiary,
    background = BlueThemeBackground,
    surface = BlueThemeSurface,
    surfaceVariant = Color(0xFF1E3A8A),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF1E40AF)
)

private val CyanScheme = darkColorScheme(
    primary = CyanThemePrimary,
    secondary = CyanThemeSecondary,
    tertiary = CyanThemeTertiary,
    background = CyanThemeBackground,
    surface = CyanThemeSurface,
    surfaceVariant = Color(0xFF134E4A),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF0F766E)
)

private val VioletScheme = darkColorScheme(
    primary = VioletThemePrimary,
    secondary = VioletThemeSecondary,
    tertiary = VioletThemeTertiary,
    background = VioletThemeBackground,
    surface = VioletThemeSurface,
    surfaceVariant = Color(0xFF2E1065),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF4C1D95)
)

private val EmeraldScheme = darkColorScheme(
    primary = EmeraldThemePrimary,
    secondary = EmeraldThemeSecondary,
    tertiary = EmeraldThemeTertiary,
    background = EmeraldThemeBackground,
    surface = EmeraldThemeSurface,
    surfaceVariant = Color(0xFF064E3B),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF047857)
)

private val RoseScheme = darkColorScheme(
    primary = RoseThemePrimary,
    secondary = RoseThemeSecondary,
    tertiary = RoseThemeTertiary,
    background = RoseThemeBackground,
    surface = RoseThemeSurface,
    surfaceVariant = Color(0xFF881337),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF9F1239)
)

private val SunsetScheme = darkColorScheme(
    primary = SunsetThemePrimary,
    secondary = SunsetThemeSecondary,
    tertiary = SunsetThemeTertiary,
    background = SunsetThemeBackground,
    surface = SunsetThemeSurface,
    surfaceVariant = Color(0xFF7C2D12),
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF9A3412)
)

private val MixedScheme = darkColorScheme(
    primary = MixedThemePrimary,
    secondary = MixedThemeSecondary,
    tertiary = MixedThemeTertiary,
    background = MixedThemeBackground,
    surface = MixedThemeSurface,
    surfaceVariant = Color(0xFF261E42),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF4C1D95)
)

@Composable
fun CallOraTheme(
    selectedTheme: AppTheme = AppTheme.DARK,
    content: @Composable () -> Unit
) {
    val colorScheme: ColorScheme = when (selectedTheme) {
        AppTheme.DARK -> DarkScheme
        AppTheme.LIGHT -> LightScheme
        AppTheme.MIDNIGHT -> MidnightScheme
        AppTheme.PURPLE -> PurpleScheme
        AppTheme.BLUE -> BlueScheme
        AppTheme.CYAN -> CyanScheme
        AppTheme.VIOLET -> VioletScheme
        AppTheme.EMERALD -> EmeraldScheme
        AppTheme.ROSE -> RoseScheme
        AppTheme.SUNSET -> SunsetScheme
        AppTheme.MIXED_PREMIUM -> MixedScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility wrapper for template previews
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    CallOraTheme(
        selectedTheme = if (darkTheme) AppTheme.DARK else AppTheme.LIGHT,
        content = content
    )
}
