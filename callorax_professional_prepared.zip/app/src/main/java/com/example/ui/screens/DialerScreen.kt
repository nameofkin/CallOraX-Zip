package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.CalloraXAdBanner
import com.example.data.local.ContactItemEntity
import com.example.telephony.CallManager
import com.example.ui.components.KeypadView
import com.example.ui.theme.CalloraViolet
import com.example.ui.theme.KeypadBgDark
import com.example.ui.theme.KeypadTextLight
import com.example.viewmodel.CallOraViewModel

@Composable
fun DialerScreen(
    viewModel: CallOraViewModel,
    onNavigateToInCall: (String) -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val dialerInput by viewModel.dialerInput.collectAsState()
    val allContacts by viewModel.allContacts.collectAsState()
    val simCards by viewModel.simCards.collectAsState()
    val defaultSimSlot by viewModel.defaultSimSlot.collectAsState()

    // Filter contacts matching dialer input
    val filteredContacts = remember(dialerInput, allContacts) {
        if (dialerInput.isEmpty()) {
            allContacts.filter { it.isFavorite }.take(4)
        } else {
            allContacts.filter {
                it.phoneNumber.replace(" ", "").contains(dialerInput) ||
                it.displayName.contains(dialerInput, ignoreCase = true)
            }.take(5)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // T9 Matching Suggestions or Speed Dial Strip
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            if (filteredContacts.isNotEmpty()) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = if (dialerInput.isEmpty()) "Quick Speed Dial" else "Matching Contacts (${filteredContacts.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF94A3B8),
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    items(filteredContacts) { contact ->
                        ContactSuggestionRow(
                            contact = contact,
                            onContactClick = {
                                viewModel.setDialerInput(contact.phoneNumber)
                            },
                            onCallClick = {
                                viewModel.makeCall(contact.phoneNumber)
                            },
                            onWhatsAppClick = {
                                CallManager.openWhatsApp(context, contact.phoneNumber)
                            }
                        )
                    }
                }
            } else if (dialerInput.isNotEmpty()) {
                // Unknown number action card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF191B26)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "New Number",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = dialerInput,
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // WhatsApp shortcut
                            IconButton(
                                onClick = { CallManager.openWhatsApp(context, dialerInput) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF25D366).copy(alpha = 0.2f))
                            ) {
                                Text("WA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF25D366))
                            }
                            // SMS shortcut
                            IconButton(
                                onClick = { CallManager.openSms(context, dialerInput) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(CalloraViolet.copy(alpha = 0.2f))
                            ) {
                                Icon(Icons.Default.Message, contentDescription = "SMS", tint = CalloraViolet, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // Displayed Number Input Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = dialerInput.ifEmpty { "Enter Number" },
                fontSize = if (dialerInput.length > 12) 24.sp else 34.sp,
                fontWeight = FontWeight.Bold,
                color = if (dialerInput.isEmpty()) Color(0xFF475569) else KeypadTextLight,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialer_display_text")
            )

            // Social Shortcuts Row when input is present
            if (dialerInput.isNotEmpty()) {
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WhatsApp",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF25D366),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF25D366).copy(alpha = 0.15f))
                            .clickable { CallManager.openWhatsApp(context, dialerInput) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    Text(
                        text = "Send SMS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF38BDF8),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF38BDF8).copy(alpha = 0.15f))
                            .clickable { CallManager.openSms(context, dialerInput) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    Text(
                        text = "In-App Call Screen",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CalloraViolet,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CalloraViolet.copy(alpha = 0.15f))
                            .clickable {
                                viewModel.startInAppCallPreview(dialerInput, isIncoming = false)
                                onNavigateToInCall(dialerInput)
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Ad Banner (Non-intrusive, ZERO ads for Pro/Premium/Lifetime, disabled during calls)
        CalloraXAdBanner(
            user = currentUser,
            callState = callState,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // Keypad Grid & Call Actions
        KeypadView(
            onDigitClick = { viewModel.onDialerDigit(it) },
            onBackspace = { viewModel.onDialerBackspace() },
            onCallClick = { simSlot ->
                if (dialerInput.isNotEmpty()) {
                    viewModel.makeCall(dialerInput, simSlot)
                }
            },
            simCards = simCards,
            defaultSimSlot = defaultSimSlot
        )
    }
}

@Composable
fun ContactSuggestionRow(
    contact: ContactItemEntity,
    onContactClick: () -> Unit,
    onCallClick: () -> Unit,
    onWhatsAppClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF141724))
            .clickable(onClick = onContactClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CalloraViolet.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = contact.displayName.take(1).uppercase(),
                    fontWeight = FontWeight.Bold,
                    color = CalloraViolet,
                    fontSize = 14.sp
                )
            }

            Column {
                Text(
                    text = contact.displayName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Text(
                    text = contact.phoneNumber,
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // WhatsApp Button
            IconButton(
                onClick = onWhatsAppClick,
                modifier = Modifier.size(32.dp)
            ) {
                Text("WA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF25D366))
            }
            // Quick Call Button
            IconButton(
                onClick = onCallClick,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF10B981).copy(alpha = 0.2f))
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Call",
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
