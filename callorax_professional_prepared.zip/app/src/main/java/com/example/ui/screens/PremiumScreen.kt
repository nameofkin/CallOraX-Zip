package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.CALLORA_PLANS
import com.example.data.remote.PlanTierInfo
import com.example.ui.theme.CalloraViolet
import com.example.ui.theme.PremiumGold
import com.example.ui.theme.VerifiedGreen
import com.example.viewmodel.CallOraViewModel

const val EASYPAISA_ACCOUNT_NUMBER = "03056265749"
const val EASYPAISA_ACCOUNT_TITLE = "Abdul Basit"
const val EASYPAISA_IBAN = "PK97TMFB0000000022443615"
const val BINANCE_PAY_ID = "574983226"
const val BINANCE_ACCOUNT_NAME = "Abdul Basit"
const val BINANCE_TRC20 = "TG1hEHkNkMPn1VmLvzY3nXcjAUwgn2cvjL"
const val BINANCE_BEP20 = "0xa289058b6b204953a9cf2d4154325e604ca80105"

@Composable
fun PremiumScreen(
    viewModel: CallOraViewModel
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val authLoading by viewModel.authLoading.collectAsState()
    val authMessage by viewModel.authMessage.collectAsState()
    var selectedPlanForPayment by remember { mutableStateOf<PlanTierInfo?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Hero Header Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF7C3AED), Color(0xFFC026D3), Color(0xFF2563EB))
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "Premium",
                        tint = PremiumGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "CallOra Pro & Premium",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                Text(
                    text = "Unlock AI Caller ID, Zero Ads, Verified Status Badges & 11 Designer Themes",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp)
                )

                // Current Membership Status
                Row(
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.35f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Status",
                        tint = if (currentUser?.isPro == true) VerifiedGreen else Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (currentUser?.isPro == true) "Current Status: Active Pro Member" else "Current Status: Free Plan",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Subscription Plans List
        Text(
            text = "Select a Plan",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(CALLORA_PLANS) { plan ->
                PlanTierCard(
                    plan = plan,
                    onSelectPlan = {
                        selectedPlanForPayment = plan
                    }
                )
            }
        }

        // Manual Payment Modal
        selectedPlanForPayment?.let { plan ->
            ManualPaymentDialog(
                plan = plan,
                isLoading = authLoading,
                onDismiss = { selectedPlanForPayment = null },
                onSubmitPayment = { gateway, trxId, senderTitle, receiptUri ->
                    viewModel.submitManualPayment(
                        plan = plan,
                        gateway = gateway,
                        trxId = trxId,
                        senderTitle = senderTitle,
                        screenshotUri = receiptUri
                    )
                    selectedPlanForPayment = null
                }
            )
        }
    }
}

@Composable
fun PlanTierCard(
    plan: PlanTierInfo,
    onSelectPlan: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelectPlan)
            .testTag("plan_card_${plan.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = plan.displayName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    plan.badge?.let { badge ->
                        Text(
                            text = badge,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (badge == "FREE TRIAL") Color(0xFF10B981)
                                    else if (badge == "BEST VALUE") Color(0xFFF59E0B)
                                    else CalloraViolet
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = if (plan.isPro) "Pro: No ads, Green verified badge, Pro caller features"
                           else "Premium: Gray verified tick, All 11 themes, Future premium suite",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Price & Button
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (plan.pricePkr == 0) "FREE" else "Rs. ${plan.pricePkr}",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = if (plan.pricePkr == 0) VerifiedGreen else MaterialTheme.colorScheme.primary
                )
                Text(
                    text = plan.durationText,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }
}

@Composable
fun ManualPaymentDialog(
    plan: PlanTierInfo,
    isLoading: Boolean,
    onDismiss: () -> Unit,
    onSubmitPayment: (gateway: String, trxId: String, senderTitle: String?, receiptUri: String) -> Unit
) {
    val context = LocalContext.current
    var selectedGateway by remember { mutableStateOf("easypaisa") } // easypaisa, binance_trc20, binance_bep20
    var trxId by remember { mutableStateOf("") }
    var senderTitle by remember { mutableStateOf("") }
    var receiptScreenshotUri by remember { mutableStateOf<Uri?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            receiptScreenshotUri = uri
        }
    }

    val copyToClipboard = { label: String, text: String ->
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Manual Payment", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    text = "${plan.displayName} • Rs. ${plan.pricePkr}",
                    fontSize = 13.sp,
                    color = CalloraViolet
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Payment Method Selector
                Text("1. Select Payment Method", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedGateway == "easypaisa",
                        onClick = { selectedGateway = "easypaisa" },
                        label = { Text("Easypaisa", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedGateway == "binance_pay",
                        onClick = { selectedGateway = "binance_pay" },
                        label = { Text("Binance Pay", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedGateway == "binance_crypto",
                        onClick = { selectedGateway = "binance_crypto" },
                        label = { Text("USDT Crypto", fontSize = 11.sp) }
                    )
                }

                // Account / Wallet Details Box with Copy Button
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            val accountTitle = when (selectedGateway) {
                                "easypaisa" -> "Easypaisa (Title: $EASYPAISA_ACCOUNT_TITLE)"
                                "binance_pay" -> "Binance Pay ID (Name: $BINANCE_ACCOUNT_NAME)"
                                else -> "Binance TRC20 / BEP20 Address"
                            }
                            val accountValue = when (selectedGateway) {
                                "easypaisa" -> "$EASYPAISA_ACCOUNT_NUMBER\nIBAN: $EASYPAISA_IBAN"
                                "binance_pay" -> BINANCE_PAY_ID
                                else -> "TRC20: $BINANCE_TRC20\nBEP20: $BINANCE_BEP20"
                            }
                            Text(accountTitle, fontSize = 10.sp, color = Color(0xFF94A3B8))
                            Text(
                                text = accountValue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        IconButton(
                            onClick = {
                                val value = when (selectedGateway) {
                                    "easypaisa" -> EASYPAISA_ACCOUNT_NUMBER
                                    "binance_pay" -> BINANCE_PAY_ID
                                    else -> BINANCE_TRC20
                                }
                                copyToClipboard("Account", value)
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CalloraViolet)
                        }
                    }
                }

                // Inputs: Sender Title & Transaction ID
                OutlinedTextField(
                    value = senderTitle,
                    onValueChange = { senderTitle = it },
                    label = { Text("Sender Account Title / Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = trxId,
                    onValueChange = { trxId = it },
                    label = { Text("Transaction / Reference ID *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Screenshot Upload (Zero-permission Android Photo Picker)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E293B))
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (receiptScreenshotUri != null) Icons.Default.Check else Icons.Default.Image,
                        contentDescription = "Upload Slip",
                        tint = if (receiptScreenshotUri != null) VerifiedGreen else CalloraViolet
                    )
                    Column {
                        Text(
                            text = if (receiptScreenshotUri != null) "Receipt Attached ✓" else "Upload Payment Screenshot *",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (receiptScreenshotUri != null) receiptScreenshotUri.toString().takeLast(25) else "Required for admin verification",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                if (receiptScreenshotUri == null) {
                    Text(
                        text = "⚠️ Payment screenshot is REQUIRED to submit.",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFF59E0B)
                    )
                }

                Text(
                    text = "ℹ️ Note: After submission, status will be 'Pending'. Our admin reviews and approves submissions promptly.",
                    fontSize = 10.sp,
                    color = Color(0xFF94A3B8),
                    lineHeight = 14.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (trxId.isNotBlank() && receiptScreenshotUri != null) {
                        onSubmitPayment(
                            selectedGateway,
                            trxId.trim(),
                            senderTitle.trim().takeIf { it.isNotEmpty() },
                            receiptScreenshotUri.toString()
                        )
                    }
                },
                enabled = trxId.isNotBlank() && receiptScreenshotUri != null && !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                } else {
                    Text("Submit for Approval")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
