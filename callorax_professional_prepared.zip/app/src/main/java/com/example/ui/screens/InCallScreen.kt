package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CallerIdBadge
import com.example.ui.components.CallerIdType
import com.example.ui.theme.CalloraViolet
import com.example.ui.theme.SpamRed
import com.example.viewmodel.CallOraViewModel
import com.example.viewmodel.CallState

@Composable
fun InCallScreen(
    viewModel: CallOraViewModel,
    onBack: () -> Unit
) {
    val callState by viewModel.callState.collectAsState()
    val activeCall by viewModel.activeCall.collectAsState()
    var showKeypadOverlay by remember { mutableStateOf(false) }
    var showNoteDialog by remember { mutableStateOf(false) }
    var inCallNoteText by remember { mutableStateOf("") }

    val call = activeCall ?: return Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0D17)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("No active call", color = Color.White)
            Spacer(modifier = Modifier.height(12.dp))
            Button(onClick = onBack) { Text("Return") }
        }
    }

    val formattedDuration = remember(call.durationSeconds) {
        val mins = call.durationSeconds / 60
        val secs = call.durationSeconds % 60
        String.format("%02d:%02d", mins, secs)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0B0D17),
                        Color(0xFF13172A),
                        Color(0xFF0A0C14)
                    )
                )
            )
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Section: SIM Indicator & Caller ID
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 24.dp)
            ) {
                // SIM Slot pill
                Text(
                    text = "SIM ${call.simSlot + 1} Active",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CalloraViolet,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CalloraViolet.copy(alpha = 0.2f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Avatar Container
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(
                            if (call.isSpam) SpamRed.copy(alpha = 0.2f)
                            else CalloraViolet.copy(alpha = 0.25f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = (call.displayName ?: call.phoneNumber).take(1).uppercase(),
                        fontSize = 36.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (call.isSpam) SpamRed else Color.White
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Caller Name
                Text(
                    text = call.displayName ?: "Unknown Caller",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                // Caller Phone
                Text(
                    text = call.phoneNumber,
                    fontSize = 15.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.padding(top = 4.dp)
                )

                // Caller ID Status Badge
                CallerIdBadge(
                    type = if (call.isSpam) CallerIdType.SPAM else CallerIdType.KNOWN,
                    customText = if (call.isSpam) (call.spamCategory ?: "Suspected Scam") else "CallOra Verified",
                    modifier = Modifier.padding(top = 8.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Call Duration or Ringing Status
                Text(
                    text = when (callState) {
                        CallState.INCOMING -> "Incoming Call..."
                        CallState.ACTIVE -> formattedDuration
                        CallState.POST_CALL -> "Call Ended (${formattedDuration})"
                        else -> "Connecting..."
                    },
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (callState == CallState.ACTIVE) Color(0xFF10B981) else Color(0xFF38BDF8)
                )
            }

            // Middle Section: In-Call Controls or Incoming Options
            if (callState == CallState.ACTIVE) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Legal Recording Notice Banner (if recording)
                    if (call.isRecording) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FiberManualRecord,
                                    contentDescription = "Recording",
                                    tint = SpamRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Call Recording Active (Compliant Mode). Two-party consent notice.",
                                    fontSize = 11.sp,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                        }
                    }

                    // 2x3 Grid of in-call actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        CallControlButton(
                            icon = if (call.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            label = if (call.isMuted) "Unmute" else "Mute",
                            isActive = call.isMuted,
                            onClick = { viewModel.toggleMute() }
                        )
                        CallControlButton(
                            icon = Icons.Default.Dialpad,
                            label = "Keypad",
                            isActive = showKeypadOverlay,
                            onClick = { showKeypadOverlay = !showKeypadOverlay }
                        )
                        CallControlButton(
                            icon = if (call.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                            label = "Speaker",
                            isActive = call.isSpeakerOn,
                            onClick = { viewModel.toggleSpeaker() }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        CallControlButton(
                            icon = if (call.isOnHold) Icons.Default.PlayArrow else Icons.Default.Pause,
                            label = if (call.isOnHold) "Resume" else "Hold",
                            isActive = call.isOnHold,
                            onClick = { viewModel.toggleHold() }
                        )
                        CallControlButton(
                            icon = Icons.Default.FiberManualRecord,
                            label = if (call.isRecording) "Stop Rec" else "Record",
                            isActive = call.isRecording,
                            onClick = { viewModel.toggleCallRecording() }
                        )
                        CallControlButton(
                            icon = Icons.Default.NoteAdd,
                            label = "Add Note",
                            isActive = false,
                            onClick = { showNoteDialog = true }
                        )
                    }
                }
            }

            // Bottom Action Row: Decline / Accept or End Call
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                if (callState == CallState.INCOMING) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Decline
                        IconButton(
                            onClick = {
                                viewModel.declineCall()
                                onBack()
                            },
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444))
                                .testTag("decline_call_button")
                        ) {
                            Icon(Icons.Default.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(32.dp))
                        }

                        // Accept
                        IconButton(
                            onClick = { viewModel.acceptIncomingCall() },
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                                .testTag("accept_call_button")
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Accept", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                    }
                } else if (callState == CallState.ACTIVE) {
                    // End Call Button
                    IconButton(
                        onClick = {
                            viewModel.endActiveCall()
                        },
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEF4444))
                            .testTag("end_active_call_button")
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                } else if (callState == CallState.POST_CALL) {
                    // Post Call Action Sheet
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { showNoteDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CalloraViolet),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save Quick Note to Notepad")
                        }

                        // Post-Call Spam & Block Actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.reportSpamNumber(
                                        phoneNumber = call.phoneNumber,
                                        callerName = call.displayName,
                                        risk = "high",
                                        details = "Reported directly from post-call summary"
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SpamRed.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Report, contentDescription = "Report", tint = SpamRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Report Spam", color = SpamRed, fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    viewModel.toggleBlockNumber(call.phoneNumber, isBlocked = true)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Block, contentDescription = "Block", tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Block", color = Color.White, fontSize = 12.sp)
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.dismissPostCall()
                                onBack()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Done / Close")
                        }
                    }
                }
            }
        }

        // In-Call Note Dialog
        if (showNoteDialog) {
            AlertDialog(
                onDismissRequest = { showNoteDialog = false },
                title = { Text("Call Note") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Linked to ${call.displayName ?: call.phoneNumber}",
                            fontSize = 12.sp,
                            color = CalloraViolet
                        )
                        OutlinedTextField(
                            value = inCallNoteText,
                            onValueChange = { inCallNoteText = it },
                            placeholder = { Text("Write notes, reminders, or action items...") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (inCallNoteText.isNotBlank()) {
                                viewModel.addNote(
                                    title = "Note with ${call.displayName ?: call.phoneNumber}",
                                    content = inCallNoteText.trim(),
                                    phoneNumber = call.phoneNumber
                                )
                                inCallNoteText = ""
                            }
                            showNoteDialog = false
                        }
                    ) {
                        Text("Save to Notepad")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showNoteDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun CallControlButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = if (isActive) Color.White else Color(0x26FFFFFF),
            modifier = Modifier.size(56.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) Color.Black else Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color(0xFFCBD5E1)
        )
    }
}
