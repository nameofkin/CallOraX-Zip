package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ads.CalloraXAdBanner
import com.example.data.local.CallRecordEntity
import com.example.telephony.CallManager
import com.example.ui.components.CallerIdBadge
import com.example.ui.components.CallerIdType
import com.example.ui.theme.CalloraViolet
import com.example.ui.theme.SpamRed
import com.example.viewmodel.CallOraViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecentsScreen(
    viewModel: CallOraViewModel,
    onNavigateToInCall: (String) -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val recents by viewModel.recents.collectAsState()
    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Missed", "Blocked", "Incoming", "Outgoing")

    val filteredList = remember(recents, selectedFilter) {
        when (selectedFilter) {
            "Missed" -> recents.filter { it.callType == "MISSED" }
            "Blocked" -> recents.filter { it.callType == "BLOCKED" || it.isSpam }
            "Incoming" -> recents.filter { it.callType == "INCOMING" }
            "Outgoing" -> recents.filter { it.callType == "OUTGOING" }
            else -> recents
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
    ) {
        // Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            items(filters) { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { selectedFilter = filter },
                    label = { Text(filter, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CalloraViolet.copy(alpha = 0.25f),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("recents_filter_$filter")
                )
            }
        }

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "No Recents",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No recent calls in $selectedFilter",
                        fontSize = 15.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredList, key = { it.id }) { record ->
                    RecentCallCard(
                        record = record,
                        onCallClick = { viewModel.makeCall(record.phoneNumber) },
                        onInCallPreview = {
                            viewModel.startInAppCallPreview(record.phoneNumber, isIncoming = false)
                            onNavigateToInCall(record.phoneNumber)
                        },
                        onWhatsAppClick = { CallManager.openWhatsApp(context, record.phoneNumber) },
                        onSmsClick = { CallManager.openSms(context, record.phoneNumber) },
                        onBlockClick = { viewModel.toggleBlockNumber(record.phoneNumber, true) },
                        onReportSpam = {
                            viewModel.reportSpamNumber(record.phoneNumber, record.displayName, "high", "Reported from Recents")
                        }
                    )
                }
            }
        }

        // Ad Banner (Auto-hidden for Pro/Premium/Lifetime/Admin or during calls)
        CalloraXAdBanner(
            user = currentUser,
            callState = callState,
            modifier = Modifier.padding(vertical = 4.dp)
        )
    }
}

@Composable
fun RecentCallCard(
    record: CallRecordEntity,
    onCallClick: () -> Unit,
    onInCallPreview: () -> Unit,
    onWhatsAppClick: () -> Unit,
    onSmsClick: () -> Unit,
    onBlockClick: () -> Unit,
    onReportSpam: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    val formattedTime = remember(record.timestamp) {
        SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(record.timestamp))
    }

    val callTypeIcon = when (record.callType) {
        "OUTGOING" -> Icons.AutoMirrored.Filled.CallMade to Color(0xFF38BDF8)
        "MISSED" -> Icons.AutoMirrored.Filled.CallMissed to SpamRed
        "BLOCKED" -> Icons.Default.Block to SpamRed
        else -> Icons.AutoMirrored.Filled.CallReceived to Color(0xFF10B981)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Call Type Icon & Info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Call icon container
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(callTypeIcon.second.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = callTypeIcon.first,
                        contentDescription = record.callType,
                        tint = callTypeIcon.second,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = record.displayName ?: record.phoneNumber,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        // SIM Indicator
                        Text(
                            text = "SIM ${record.simSlot + 1}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = CalloraViolet,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CalloraViolet.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }

                    Text(
                        text = record.phoneNumber,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = formattedTime,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                        if (record.durationSeconds > 0) {
                            Text(
                                text = "• ${record.durationSeconds}s",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }
                    }

                    // Caller ID Status Badge
                    if (record.isSpam) {
                        CallerIdBadge(
                            type = CallerIdType.SPAM,
                            customText = record.spamCategory ?: "Suspected Spam",
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Right Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // WhatsApp
                IconButton(onClick = onWhatsAppClick, modifier = Modifier.size(34.dp)) {
                    Text("WA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF25D366))
                }

                // Call
                IconButton(
                    onClick = onCallClick,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981).copy(alpha = 0.2f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(16.dp)
                    )
                }

                // More Menu
                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Simulate In-App Call") },
                            onClick = {
                                showMenu = false
                                onInCallPreview()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Send SMS") },
                            onClick = {
                                showMenu = false
                                onSmsClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Report as Spam") },
                            onClick = {
                                showMenu = false
                                onReportSpam()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Block Number") },
                            onClick = {
                                showMenu = false
                                onBlockClick()
                            }
                        )
                    }
                }
            }
        }
    }
}
