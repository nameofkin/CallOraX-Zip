package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CallOra Core Brand Colors
val CalloraViolet = Color(0xFF8B5CF6)
val CalloraVioletDark = Color(0xFF7C3AED)
val CalloraCyan = Color(0xFF06B6D4)
val CalloraBlue = Color(0xFF3B82F6)

// Dark / Slate Backgrounds
val ObsidianDark = Color(0xFF0B0D17)
val SurfaceDark = Color(0xFF11131D)
val CardSurfaceDark = Color(0xFF191B26)
val BorderDark = Color(0xFF262938)

// Status Colors
val SpamRed = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF59E0B)
val VerifiedGreen = Color(0xFF10B981)
val PremiumGold = Color(0xFFFBBF24)
val GrayTick = Color(0xFF94A3B8)

// Keypad Specific
val KeypadBgDark = Color(0xFF0A0C14)
val KeypadButtonBg = Color(0x1AFFFFFF)
val KeypadButtonPressed = Color(0x33FFFFFF)
val KeypadTextLight = Color(0xFFF8FAFC)
val KeypadLettersSubtle = Color(0xFF94A3B8)

// Theme 1: Dark (Default)
val DarkPrimary = Color(0xFF8B5CF6)
val DarkSecondary = Color(0xFF06B6D4)
val DarkTertiary = Color(0xFF3B82F6)
val DarkBackground = Color(0xFF0B0D17)
val DarkSurface = Color(0xFF11131D)

// Theme 2: Light
val LightPrimary = Color(0xFF7C3AED)
val LightSecondary = Color(0xFF0284C7)
val LightTertiary = Color(0xFF4F46E5)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)

// Theme 3: Midnight
val MidnightPrimary = Color(0xFF38BDF8)
val MidnightSecondary = Color(0xFF818CF8)
val MidnightTertiary = Color(0xFF60A5FA)
val MidnightBackground = Color(0xFF030712)
val MidnightSurface = Color(0xFF0F172A)

// Theme 4: Purple
val PurpleThemePrimary = Color(0xFFA855F7)
val PurpleThemeSecondary = Color(0xFFEC4899)
val PurpleThemeTertiary = Color(0xFFC084FC)
val PurpleThemeBackground = Color(0xFF13071E)
val PurpleThemeSurface = Color(0xFF1F0D33)

// Theme 5: Blue
val BlueThemePrimary = Color(0xFF2563EB)
val BlueThemeSecondary = Color(0xFF38BDF8)
val BlueThemeTertiary = Color(0xFF60A5FA)
val BlueThemeBackground = Color(0xFF0B132B)
val BlueThemeSurface = Color(0xFF1C2541)

// Theme 6: Cyan
val CyanThemePrimary = Color(0xFF06B6D4)
val CyanThemeSecondary = Color(0xFF14B8A6)
val CyanThemeTertiary = Color(0xFF22D3EE)
val CyanThemeBackground = Color(0xFF04181B)
val CyanThemeSurface = Color(0xFF082F35)

// Theme 7: Violet
val VioletThemePrimary = Color(0xFF7C3AED)
val VioletThemeSecondary = Color(0xFF9333EA)
val VioletThemeTertiary = Color(0xFFA78BFA)
val VioletThemeBackground = Color(0xFF0E0720)
val VioletThemeSurface = Color(0xFF180E38)

// Theme 8: Emerald
val EmeraldThemePrimary = Color(0xFF10B981)
val EmeraldThemeSecondary = Color(0xFF059669)
val EmeraldThemeTertiary = Color(0xFF34D399)
val EmeraldThemeBackground = Color(0xFF02170E)
val EmeraldThemeSurface = Color(0xFF062E1D)

// Theme 9: Rose
val RoseThemePrimary = Color(0xFFF43F5E)
val RoseThemeSecondary = Color(0xFFFB7185)
val RoseThemeTertiary = Color(0xFFFDA4AF)
val RoseThemeBackground = Color(0xFF1A060B)
val RoseThemeSurface = Color(0xFF2D0D15)

// Theme 10: Sunset
val SunsetThemePrimary = Color(0xFFF97316)
val SunsetThemeSecondary = Color(0xFFEF4444)
val SunsetThemeTertiary = Color(0xFFFBBF24)
val SunsetThemeBackground = Color(0xFF180A04)
val SunsetThemeSurface = Color(0xFF2A1207)

// Theme 11: Mixed Premium
val MixedThemePrimary = Color(0xFFEAB308)
val MixedThemeSecondary = Color(0xFFA855F7)
val MixedThemeTertiary = Color(0xFF06B6D4)
val MixedThemeBackground = Color(0xFF0C0A14)
val MixedThemeSurface = Color(0xFF181427)
