package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CallOraRepository
import com.example.data.local.CallRecordEntity
import com.example.data.local.ContactItemEntity
import com.example.data.local.NoteEntity
import com.example.data.local.RecordingItemEntity
import com.example.data.remote.CALLORA_PLANS
import com.example.data.remote.CallerDirectoryEntry
import com.example.data.remote.CommunityPost
import com.example.data.remote.PaymentSubmission
import com.example.data.remote.PlanTierInfo
import com.example.data.remote.UserProfile
import com.example.telephony.CallAudioRecorder
import com.example.telephony.CallManager
import com.example.telephony.DualSimManager
import com.example.telephony.SimCardInfo
import com.example.ui.theme.AppTheme
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class CallState {
    IDLE,
    INCOMING,
    ACTIVE,
    POST_CALL
}

data class ActiveCallData(
    val phoneNumber: String,
    val displayName: String?,
    val isSpam: Boolean = false,
    val spamCategory: String? = null,
    val simSlot: Int = 0,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val isOnHold: Boolean = false,
    val isRecording: Boolean = false
)

class CallOraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = CallOraRepository(application)
    val recorder = CallAudioRecorder(application)
    private val audioManager = application.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // Preferences
    private val appPrefs = application.getSharedPreferences("callora_settings", Context.MODE_PRIVATE)

    // Current Theme State
    private val _currentTheme = MutableStateFlow(loadSavedTheme())
    val currentTheme: StateFlow<AppTheme> = _currentTheme.asStateFlow()

    // Auth & Profile State
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authMessage = MutableStateFlow<String?>(null)
    val authMessage: StateFlow<String?> = _authMessage.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authSuccess = MutableStateFlow<String?>(null)
    val authSuccess: StateFlow<String?> = _authSuccess.asStateFlow()

    private val _emailVerificationPending = MutableStateFlow<String?>(null)
    val emailVerificationPending: StateFlow<String?> = _emailVerificationPending.asStateFlow()

    // Dual SIM State
    private val _simCards = MutableStateFlow<List<SimCardInfo>>(emptyList())
    val simCards: StateFlow<List<SimCardInfo>> = _simCards.asStateFlow()

    private val _defaultSimSlot = MutableStateFlow(DualSimManager.getDefaultSimPreference(application))
    val defaultSimSlot: StateFlow<Int> = _defaultSimSlot.asStateFlow()

    // Dialer & Contacts State
    private val _dialerInput = MutableStateFlow("")
    val dialerInput: StateFlow<String> = _dialerInput.asStateFlow()

    private val _allContacts = MutableStateFlow<List<ContactItemEntity>>(emptyList())
    val allContacts: StateFlow<List<ContactItemEntity>> = _allContacts.asStateFlow()

    private val _recents = MutableStateFlow<List<CallRecordEntity>>(emptyList())
    val recents: StateFlow<List<CallRecordEntity>> = _recents.asStateFlow()

    // In-Call & Incoming Call State
    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _activeCall = MutableStateFlow<ActiveCallData?>(null)
    val activeCall: StateFlow<ActiveCallData?> = _activeCall.asStateFlow()

    private var callTimerJob: Job? = null

    // Notepad State
    private val _notes = MutableStateFlow<List<NoteEntity>>(emptyList())
    val notes: StateFlow<List<NoteEntity>> = _notes.asStateFlow()

    private val _notesSearchQuery = MutableStateFlow("")
    val notesSearchQuery: StateFlow<String> = _notesSearchQuery.asStateFlow()

    // Voice Recordings
    private val _recordings = MutableStateFlow<List<RecordingItemEntity>>(emptyList())
    val recordings: StateFlow<List<RecordingItemEntity>> = _recordings.asStateFlow()

    // Community Posts
    private val _communityPosts = MutableStateFlow<List<CommunityPost>>(emptyList())
    val communityPosts: StateFlow<List<CommunityPost>> = _communityPosts.asStateFlow()

    // Admin & Payments State
    private val _pendingPayments = MutableStateFlow<List<PaymentSubmission>>(emptyList())
    val pendingPayments: StateFlow<List<PaymentSubmission>> = _pendingPayments.asStateFlow()

    private val _allUsersList = MutableStateFlow<List<UserProfile>>(emptyList())
    val allUsersList: StateFlow<List<UserProfile>> = _allUsersList.asStateFlow()

    // Caller Directory Cache
    private val _callerDirectoryMap = MutableStateFlow<Map<String, CallerDirectoryEntry>>(emptyMap())
    val callerDirectoryMap: StateFlow<Map<String, CallerDirectoryEntry>> = _callerDirectoryMap.asStateFlow()

    init {
        refreshSims()
        loadInitialContacts()
        observeLocalData()
        checkAuthSession()
        loadCommunity()
        loadAdminData()
    }

    private fun loadSavedTheme(): AppTheme {
        val themeName = appPrefs.getString("app_theme", AppTheme.DARK.name) ?: AppTheme.DARK.name
        return try {
            AppTheme.valueOf(themeName)
        } catch (e: Exception) {
            AppTheme.DARK
        }
    }

    fun setTheme(theme: AppTheme) {
        // Enforce backend/pro entitlement check: if theme is premium only, user must have active entitlement
        if (theme.isPremiumOnly) {
            val user = _currentUser.value
            val isEntitled = user?.hasActiveEntitlement == true
            if (!isEntitled) {
                _authMessage.value = "Theme '${theme.displayName}' requires CallOra Pro or Premium subscription."
                return
            }
        }
        _currentTheme.value = theme
        appPrefs.edit().putString("app_theme", theme.name).apply()
    }

    // ==========================================
    // AUTHENTICATION & PROFILE
    // ==========================================

    private fun checkAuthSession() {
        val session = repository.currentSession
        if (session != null) {
            fetchUserProfile(session.user.id)
        } else {
            _currentUser.value = null
        }
    }

    fun signInEmail(email: String, pass: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            _authSuccess.value = null
            _authMessage.value = null
            val result = repository.signInEmail(email, pass)
            result.onSuccess { session ->
                fetchUserProfile(session.user.id)
                _authLoading.value = false
                _authSuccess.value = "Welcome back!"
                _authMessage.value = "Welcome back!"
            }.onFailure { err ->
                _authLoading.value = false
                val msg = err.message ?: "Authentication failed"
                _authError.value = msg
                _authMessage.value = msg
                if (msg.contains("Email not confirmed", ignoreCase = true) || msg.contains("email_not_confirmed", ignoreCase = true)) {
                    _emailVerificationPending.value = email.trim()
                }
            }
        }
    }

    fun signUpEmail(email: String, pass: String, fullName: String, phone: String?) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            _authSuccess.value = null
            _authMessage.value = null
            val result = repository.signUpEmail(email, pass, fullName, phone)
            result.onSuccess { outcome ->
                _authLoading.value = false
                if (outcome.session != null) {
                    fetchUserProfile(outcome.session.user.id)
                    _authSuccess.value = outcome.message
                    _authMessage.value = outcome.message
                } else {
                    _emailVerificationPending.value = outcome.email
                    _authSuccess.value = outcome.message
                    _authMessage.value = outcome.message
                }
            }.onFailure { err ->
                _authLoading.value = false
                val msg = err.message ?: "Sign up failed"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun resendVerificationEmail(email: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.resendVerificationEmail(email)
            _authLoading.value = false
            result.onSuccess { msg ->
                _authSuccess.value = msg
                _authMessage.value = msg
            }.onFailure { err ->
                val msg = err.message ?: "Failed to resend email"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun verifyEmailToken(email: String, token: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.verifyEmailToken(email, token)
            _authLoading.value = false
            result.onSuccess { session ->
                _emailVerificationPending.value = null
                fetchUserProfile(session.user.id)
                _authSuccess.value = "Email verified successfully! Account active."
                _authMessage.value = "Email verified successfully!"
            }.onFailure { err ->
                val msg = err.message ?: "Invalid verification code"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun sendPhoneOtp(phone: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.sendPhoneOtp(phone)
            _authLoading.value = false
            result.onSuccess { msg ->
                _authSuccess.value = msg
                _authMessage.value = msg
            }.onFailure { err ->
                val msg = err.message ?: "Failed to send OTP"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun verifyPhoneOtp(phone: String, code: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.verifyPhoneOtp(phone, code)
            _authLoading.value = false
            result.onSuccess { session ->
                fetchUserProfile(session.user.id)
                _authSuccess.value = "Phone verification successful!"
                _authMessage.value = "Phone verification successful!"
            }.onFailure { err ->
                val msg = err.message ?: "Invalid OTP code"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun resetPassword(email: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val res = repository.resetPassword(email)
            _authLoading.value = false
            res.onSuccess { msg ->
                _authSuccess.value = msg
                _authMessage.value = msg
            }.onFailure { err ->
                val msg = err.message ?: "Failed to send password reset"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun launchGoogleOAuth(context: Context) {
        try {
            val url = repository.getGoogleOAuthUrl()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val msg = "Unable to open browser for Google authentication: ${e.message}"
            _authError.value = msg
            _authMessage.value = msg
        }
    }

    fun handleAuthDeepLink(uri: Uri) {
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.handleOAuthCallback(uri)
            _authLoading.value = false
            result.onSuccess { session ->
                fetchUserProfile(session.user.id)
                _authSuccess.value = "Signed in successfully with Google OAuth!"
                _authMessage.value = "Signed in successfully with Google!"
            }.onFailure { err ->
                val msg = err.message ?: "OAuth login failed"
                _authError.value = msg
                _authMessage.value = msg
            }
        }
    }

    fun signOut() {
        repository.signOut()
        _currentUser.value = null
        _emailVerificationPending.value = null
        _authSuccess.value = "Logged out successfully"
        _authMessage.value = "Logged out successfully"
    }

    fun deleteAccount() {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _authLoading.value = true
            repository.deleteAccount(user.id)
            _currentUser.value = null
            _emailVerificationPending.value = null
            _authLoading.value = false
            _authSuccess.value = "Account deleted successfully."
            _authMessage.value = "Account deleted successfully."
        }
    }

    fun updateProfile(fullName: String, phone: String?, avatarUrl: String?) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repository.updateProfile(user.id, fullName, phone, avatarUrl)
            fetchUserProfile(user.id)
            _authMessage.value = "Profile updated."
        }
    }

    private fun fetchUserProfile(userId: String) {
        viewModelScope.launch {
            val result = repository.getProfile(userId)
            result.onSuccess { profile ->
                _currentUser.value = profile
            }
        }
    }

    // ==========================================
    // DUAL SIM MANAGEMENT
    // ==========================================

    fun refreshSims() {
        _simCards.value = DualSimManager.getActiveSims(getApplication())
    }

    fun setDefaultSim(slot: Int) {
        _defaultSimSlot.value = slot
        DualSimManager.setDefaultSimPreference(getApplication(), slot)
    }

    // ==========================================
    // DIALER & CONTACTS
    // ==========================================

    fun onDialerDigit(digit: String) {
        _dialerInput.value += digit
    }

    fun onDialerBackspace() {
        if (_dialerInput.value.isNotEmpty()) {
            _dialerInput.value = _dialerInput.value.dropLast(1)
        }
    }

    fun clearDialer() {
        _dialerInput.value = ""
    }

    fun setDialerInput(number: String) {
        _dialerInput.value = number
    }

    fun insertContact(contact: ContactItemEntity) {
        viewModelScope.launch {
            repository.insertContact(contact)
        }
    }

    fun toggleFavorite(number: String, isFav: Boolean) {
        viewModelScope.launch {
            repository.toggleFavorite(number, isFav)
        }
    }

    fun makeCall(phoneNumber: String, simSlot: Int? = null) {
        val effectiveSimSlot = simSlot ?: if (_defaultSimSlot.value >= 0) _defaultSimSlot.value else 0
        CallManager.makeCall(getApplication(), phoneNumber, effectiveSimSlot)

        // Record in Recents
        val contactName = _allContacts.value.find { it.phoneNumber == phoneNumber }?.displayName
        viewModelScope.launch {
            repository.insertCallRecord(
                CallRecordEntity(
                    phoneNumber = phoneNumber,
                    displayName = contactName ?: "Unknown",
                    callType = "OUTGOING",
                    simSlot = effectiveSimSlot,
                    durationSeconds = 0
                )
            )
        }
    }

    fun startInAppCallPreview(phoneNumber: String, isIncoming: Boolean = false) {
        val contactName = _allContacts.value.find { it.phoneNumber == phoneNumber }?.displayName
        val directoryInfo = _callerDirectoryMap.value[phoneNumber]

        _activeCall.value = ActiveCallData(
            phoneNumber = phoneNumber,
            displayName = contactName ?: directoryInfo?.displayName ?: "Unknown Caller",
            isSpam = directoryInfo?.riskLevel in listOf("high", "severe") || directoryInfo?.spamReportsCount ?: 0 > 5,
            spamCategory = directoryInfo?.category,
            simSlot = if (_defaultSimSlot.value >= 0) _defaultSimSlot.value else 0
        )

        _callState.value = if (isIncoming) CallState.INCOMING else CallState.ACTIVE

        if (!isIncoming) {
            startCallTimer()
        }
    }

    fun acceptIncomingCall() {
        _callState.value = CallState.ACTIVE
        startCallTimer()
    }

    fun declineCall() {
        endActiveCall()
    }

    fun endActiveCall() {
        callTimerJob?.cancel()
        callTimerJob = null

        val call = _activeCall.value
        if (call != null) {
            if (call.isRecording) {
                stopRecording()
            }
            viewModelScope.launch {
                repository.insertCallRecord(
                    CallRecordEntity(
                        phoneNumber = call.phoneNumber,
                        displayName = call.displayName,
                        callType = if (_callState.value == CallState.INCOMING) "MISSED" else "INCOMING",
                        durationSeconds = call.durationSeconds,
                        simSlot = call.simSlot,
                        isSpam = call.isSpam,
                        spamCategory = call.spamCategory
                    )
                )
            }
        }

        _callState.value = CallState.POST_CALL
    }

    fun dismissPostCall() {
        _callState.value = CallState.IDLE
        _activeCall.value = null
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _activeCall.value = _activeCall.value?.let {
                    it.copy(durationSeconds = it.durationSeconds + 1)
                }
            }
        }
    }

    fun toggleMute() {
        val current = _activeCall.value ?: return
        _activeCall.value = current.copy(isMuted = !current.isMuted)
        audioManager.isMicrophoneMute = _activeCall.value?.isMuted ?: false
    }

    fun toggleSpeaker() {
        val current = _activeCall.value ?: return
        val newSpeaker = !current.isSpeakerOn
        _activeCall.value = current.copy(isSpeakerOn = newSpeaker)
        audioManager.isSpeakerphoneOn = newSpeaker
    }

    fun toggleHold() {
        val current = _activeCall.value ?: return
        _activeCall.value = current.copy(isOnHold = !current.isOnHold)
    }

    fun toggleCallRecording() {
        val current = _activeCall.value ?: return
        if (current.isRecording) {
            stopRecording()
        } else {
            val path = recorder.startRecording(current.phoneNumber)
            if (path != null) {
                _activeCall.value = current.copy(isRecording = true)
            }
        }
    }

    private fun stopRecording() {
        val path = recorder.currentRecordingPath
        val duration = recorder.stopRecording()
        val current = _activeCall.value
        _activeCall.value = current?.copy(isRecording = false)

        if (path != null && duration > 0) {
            viewModelScope.launch {
                repository.insertRecording(
                    RecordingItemEntity(
                        title = "Call with ${current?.displayName ?: current?.phoneNumber ?: "Unknown"}",
                        filePath = path,
                        durationSeconds = duration,
                        phoneNumber = current?.phoneNumber
                    )
                )
            }
        }
    }

    // ==========================================
    // NOTEPAD
    // ==========================================

    fun addNote(title: String, content: String, phoneNumber: String? = null, isPinned: Boolean = false) {
        viewModelScope.launch {
            repository.insertNote(
                NoteEntity(
                    title = title,
                    content = content,
                    phoneNumber = phoneNumber,
                    isPinned = isPinned
                )
            )
            _authMessage.value = "Note saved."
        }
    }

    fun updateNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    fun togglePinNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    fun setNotesSearchQuery(q: String) {
        _notesSearchQuery.value = q
    }

    // ==========================================
    // CALLER ID & SPAM LOOKUP / REPORT
    // ==========================================

    fun lookupCaller(phoneNumber: String) {
        viewModelScope.launch {
            val res = repository.lookupCaller(phoneNumber)
            res.getOrNull()?.let { entry ->
                _callerDirectoryMap.value = _callerDirectoryMap.value + (phoneNumber to entry)
            }
        }
    }

    fun reportSpamNumber(phoneNumber: String, callerName: String?, risk: String, details: String?) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repository.reportSpam(user.id, phoneNumber, callerName, risk, details)
            _authMessage.value = "Spam report submitted for $phoneNumber."
            // Also update local directory
            _callerDirectoryMap.value = _callerDirectoryMap.value + (phoneNumber to CallerDirectoryEntry(
                id = "rep-${System.currentTimeMillis()}",
                phoneNumber = phoneNumber,
                displayName = callerName ?: "Reported Spam",
                riskLevel = risk,
                spamReportsCount = 1,
                isVerifiedBusiness = false,
                category = "User Reported"
            ))
        }
    }

    fun toggleBlockNumber(number: String, isBlocked: Boolean) {
        viewModelScope.launch {
            repository.toggleBlock(number, isBlocked)
            _authMessage.value = if (isBlocked) "Number $number blocked" else "Number $number unblocked"
        }
    }

    // ==========================================
    // MANUAL PAYMENT SUBMISSION
    // ==========================================

    fun submitManualPayment(
        plan: PlanTierInfo,
        gateway: String, // easypaisa, binance_pay
        trxId: String,
        senderTitle: String?,
        screenshotUri: String
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            _authLoading.value = true
            val result = repository.submitPayment(
                userId = user.id,
                gw = gateway,
                tier = plan.id,
                amount = plan.pricePkr.toDouble(),
                trx = trxId,
                title = senderTitle,
                receipt = screenshotUri
            )
            _authLoading.value = false
            result.onSuccess {
                _authMessage.value = "Payment submitted. Please wait a few minutes for admin approval."
                loadAdminData()
            }.onFailure { err ->
                _authMessage.value = "Error submitting payment: ${err.message}"
            }
        }
    }

    // ==========================================
    // ADMIN PANEL
    // ==========================================

    fun loadAdminData() {
        viewModelScope.launch {
            val payments = repository.getPendingPayments()
            payments.onSuccess {
                _pendingPayments.value = it
            }
            val users = repository.getAllProfiles()
            users.onSuccess {
                _allUsersList.value = it
            }
        }
    }

    fun reviewPaymentSubmission(paymentId: String, status: String, adminNotes: String?) {
        viewModelScope.launch {
            val result = repository.reviewPayment(paymentId, status, adminNotes)
            if (result.isSuccess) {
                _authMessage.value = "Payment $status successfully!"
                loadAdminData()
                // Refresh current user in case the user approved was current user
                _currentUser.value?.let { fetchUserProfile(it.id) }
            }
        }
    }

    fun updateUserRole(userId: String, newRole: String) {
        viewModelScope.launch {
            repository.updateUserRole(userId, newRole)
            _authMessage.value = "User role updated to $newRole"
            loadAdminData()
            if (_currentUser.value?.id == userId) {
                fetchUserProfile(userId)
            }
        }
    }

    fun toggleUserBadges(userId: String, isVerified: Boolean, isPro: Boolean) {
        viewModelScope.launch {
            repository.updateUserBadges(userId, isVerified, isPro)
            _authMessage.value = "Badges updated"
            loadAdminData()
            if (_currentUser.value?.id == userId) {
                fetchUserProfile(userId)
            }
        }
    }

    // ==========================================
    // COMMUNITY
    // ==========================================

    fun loadCommunity() {
        viewModelScope.launch {
            val res = repository.getCommunityPosts()
            res.onSuccess {
                _communityPosts.value = it
            }
        }
    }

    fun createCommunityPost(category: String, caption: String, flaggedNumber: String?, imageUrl: String?) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val res = repository.createCommunityPost(user.id, category, caption, flaggedNumber, imageUrl)
            res.onSuccess { post ->
                _communityPosts.value = listOf(post) + _communityPosts.value
                _authMessage.value = "Post published to community!"
            }
        }
    }

    fun deleteCommunityPost(postId: String) {
        viewModelScope.launch {
            repository.deletePost(postId)
            _communityPosts.value = _communityPosts.value.filterNot { it.id == postId }
            _authMessage.value = "Post deleted"
        }
    }

    fun togglePostLike(postId: String) {
        _communityPosts.value = _communityPosts.value.map { post ->
            if (post.id == postId) {
                val newLiked = !post.isLikedByMe
                post.copy(
                    isLikedByMe = newLiked,
                    likesCount = if (newLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
                )
            } else post
        }
    }

    // ==========================================
    // LOCAL OBSERVATION & DATA SEEDING
    // ==========================================

    private fun observeLocalData() {
        viewModelScope.launch {
            repository.allNotes.collectLatest { noteList ->
                _notes.value = noteList
            }
        }
        viewModelScope.launch {
            repository.allCallRecords.collectLatest { recordList ->
                _recents.value = recordList
            }
        }
        viewModelScope.launch {
            repository.allContacts.collectLatest { contactList ->
                _allContacts.value = contactList
            }
        }
        viewModelScope.launch {
            repository.allRecordings.collectLatest { recList ->
                _recordings.value = recList
            }
        }
    }

    private fun loadInitialContacts() {
        viewModelScope.launch {
            val initial = listOf(
                ContactItemEntity("+92 300 1234567", "Abdul Basit Kamboh", isFavorite = true, category = "Self"),
                ContactItemEntity("+92 321 9876543", "Zain Ali (CallOra Support)", isFavorite = true, category = "Work"),
                ContactItemEntity("+92 333 5551234", "Mom", isFavorite = true, category = "Family"),
                ContactItemEntity("+92 345 8889999", "Ali Raza", isFavorite = false, category = "Personal"),
                ContactItemEntity("+92 311 0001111", "HBL Helpline (Verified)", isFavorite = false, category = "Business"),
                ContactItemEntity("+92 312 9012345", "Suspected Scam Caller", isFavorite = false, isBlocked = true, category = "Spam")
            )
            repository.insertContacts(initial)

            // Also seed a couple of recents if empty
            val initialRecents = listOf(
                CallRecordEntity(
                    phoneNumber = "+92 321 9876543",
                    displayName = "Zain Ali (CallOra Support)",
                    callType = "INCOMING",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                    durationSeconds = 142,
                    simSlot = 0
                ),
                CallRecordEntity(
                    phoneNumber = "+92 312 9012345",
                    displayName = "Suspected Scam Caller",
                    callType = "BLOCKED",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 180,
                    durationSeconds = 0,
                    simSlot = 0,
                    isSpam = true,
                    spamCategory = "State Bank Impersonator"
                ),
                CallRecordEntity(
                    phoneNumber = "+92 333 5551234",
                    displayName = "Mom",
                    callType = "OUTGOING",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 360,
                    durationSeconds = 320,
                    simSlot = 1
                )
            )
            initialRecents.forEach { repository.insertCallRecord(it) }

            // Seed an initial note
            repository.insertNote(
                NoteEntity(
                    title = "CallOra Setup & Dual SIM",
                    content = "Dual SIM active: SIM 1 Jazz, SIM 2 Telenor. Default set to Ask every time. Easypaisa manual payment verified.",
                    isPinned = true
                )
            )
        }
    }

    fun clearAuthMessage() {
        _authMessage.value = null
    }
}
